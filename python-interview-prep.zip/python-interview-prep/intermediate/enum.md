# Enum

[Back to README](../README.md) | [Exercises](../coding-exercises/README.md) | [Cheat Sheets](../cheat-sheets/README.md)

## Overview
Enum is a core Python interview topic because it reveals whether a candidate understands both everyday syntax and the deeper behavior that makes Python code reliable. Use this page to build a crisp mental model, practice explaining trade-offs, and connect the concept to real production decisions.

## Why it matters
In real projects, Enum affects API design, debugging, testability, maintainability, and performance. Senior interviewers often ask about it indirectly through code review prompts, bug diagnosis, refactoring discussions, and system design trade-offs.

## Syntax
```python
from __future__ import annotations

def demonstrate_enum() -> str:
    value = "Enum"
    return f"Practicing {value} with Python 3.12+"


if __name__ == "__main__":
    print(demonstrate_enum())
```

## Examples
```python
from __future__ import annotations

def normalize_name(name: str) -> str:
    return " ".join(part.capitalize() for part in name.strip().split())


candidates = [" ada lovelace ", "grace hopper", " guido van rossum"]
print([normalize_name(candidate) for candidate in candidates])
```

```python
from __future__ import annotations

def safe_lookup(mapping: dict[str, int], key: str, default: int = 0) -> int:
    return mapping.get(key, default)


scores = {"python": 95, "systems": 88}
print(safe_lookup(scores, "python"))
```

## Common Interview Questions
1. What is Enum, and what problem does it solve in Python?
2. How would you explain Enum to a beginner without oversimplifying it?
3. What are the most important edge cases for Enum?
4. How does Enum affect readability and maintainability?
5. What production bug could happen if Enum is misunderstood?
6. When should you avoid using Enum?
7. How would you test code that relies on Enum?
8. What is the runtime or memory cost of using Enum?
9. How does Enum interact with type hints in Python 3.12+?
10. What does a Pythonic use of Enum look like?
11. How would you refactor poorly written code that uses Enum?
12. What standard-library tools are commonly used with Enum?
13. How would Enum appear in a code review discussion?
14. What trade-off does Enum vs Literal represent?
15. How would you explain Enum in a senior-level interview?
16. What assumptions should be stated before optimizing code involving Enum?
17. How does Enum behave with invalid, empty, or very large input?
18. What security or reliability concerns can involve Enum?
19. How would you teach Enum through a practical example?
20. What is the shortest interview-quality summary of Enum?

## Detailed Answers
1. Enum is a language feature or concept that helps express intent clearly. A strong answer defines the behavior, shows a minimal example, and explains where the concept appears in production code.
2. Start with the mental model, then add precision. For Enum, the best explanation connects syntax to consequences such as mutation, allocation, control flow, or API design.
3. Important edge cases include empty input, invalid values, mutation, ordering, exception paths, and interactions with reusable functions. Interviewers value candidates who name these before coding.
4. Readable use of Enum makes the code easier to reason about. If it hides state, control flow, or side effects, it should be simplified or documented through clearer names and tests.
5. A common production failure is assuming toy-example behavior holds under concurrency, large input, unexpected data, or reused library code. The fix is to state invariants and test boundaries.
6. Avoid Enum when it adds abstraction without reducing complexity. Prefer the simplest construct that preserves correctness, observability, and future change.
7. Test normal cases, boundary cases, and failure cases. Keep tests behavior-focused so an implementation can be refactored without rewriting the entire suite.
8. Discuss Big O, allocation behavior, and whether work is eager or lazy. If performance matters, explain what you would measure before changing code.
9. Type hints document the expected contract and help static tools catch misuse. They do not replace runtime validation when untrusted data enters the system.
10. Pythonic code is explicit, idiomatic, and boring in the best way: clear names, direct control flow, standard-library usage, and no clever tricks that make review harder.
11. Refactoring starts by naming the intent, isolating side effects, adding tests around current behavior, and then replacing incidental complexity with a smaller construct.
12. Standard-library support usually exists for the common version of this problem. Mentioning it shows maturity, but you should still explain the underlying mechanics.
13. In code review, focus on correctness, edge cases, naming, complexity, and whether the abstraction helps the next maintainer understand the program.
14. The trade-off in Enum vs Literal is about choosing the construct whose constraints match the problem. Good candidates explain both sides instead of declaring one universally better.
15. A senior-level answer connects Enum to API contracts, testing strategy, operational behavior, and how the choice affects other engineers working in the codebase.
16. State input size, mutation expectations, ordering requirements, concurrency assumptions, and acceptable memory use before optimizing. Then choose the least complex improvement.
17. For invalid or large input, define expected behavior first. Robust code handles empty data, rejects bad data clearly, and avoids unnecessary full-copy operations.
18. Reliability concerns include hidden state, resource leaks, unhandled exceptions, injection risks, and unclear ownership of data. The mitigation is explicit contracts and tests.
19. A practical teaching example should start with a real task, implement the simplest working version, then discuss what changes in a larger service or library.
20. An interview-quality summary defines Enum, gives one example, names a trade-off, mentions an edge case, and states the complexity or operational impact when relevant.

## Follow-up Questions
1. How would this answer change for a public library API?
2. What would you measure before optimizing it?
3. How would you test the failure path?
4. What changes in concurrent code?
5. How does this interact with serialization or persistence?
6. What would you document for future maintainers?
7. Can you show a simpler implementation?
8. Can you show a version optimized for memory?
9. How would you explain this to a non-Python engineer?
10. What is the most common misconception?
11. Where would a linter or type checker help?
12. What would make this code hard to review?
13. How does the standard library solve this problem?
14. What changes at 10 million inputs?
15. How would you debug a production issue involving this?
16. What trade-off would you revisit after launch?
17. How could bad naming make this concept dangerous?
18. What would you mock or avoid mocking in tests?
19. How would you make the example more realistic?
20. Can you summarize the concept in one minute?

## Practical Example
```python
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class InterviewSignal:
    topic: str
    confidence: int


def summarize_signal(signal: InterviewSignal) -> str:
    if not 0 <= signal.confidence <= 100:
        raise ValueError("confidence must be between 0 and 100")
    return f"{signal.topic}: {signal.confidence}% ready"


print(summarize_signal(InterviewSignal(topic="Enum", confidence=80)))
```

## Common Mistakes
- Memorizing syntax without explaining why the feature exists.
- Ignoring edge cases such as empty input, mutation, exceptions, or resource cleanup.
- Giving answers that work for toy examples but fail when code is reused by a team.
- Forgetting to mention readability, testing, and operational behavior.

## Best Practices
- Prefer explicit, readable code over clever shortcuts.
- Use type hints for public functions and interview solutions.
- Keep functions small enough to test directly.
- Name variables after domain concepts, not implementation accidents.
- Explain trade-offs before optimizing.

## Performance Notes
Discuss both time and memory complexity. For Enum, be ready to identify constant-time operations, linear scans, allocation behavior, and when laziness or caching changes the cost model. In interviews, state assumptions before giving Big O.

## Comparison Table
| Concept | When to use | Trade-off |
|---|---|---|
| Enum | Use when it makes intent direct and maintainable. | Usually simpler, but may be less flexible. |
| Literal | Use when constraints require it. | Often more powerful, but can add complexity. |

## Coding Challenge
Write a function `explain_tradeoff(choice: str) -> str` that returns a concise recommendation for when to use one side of `Enum vs Literal`.

## Solution
```python
from __future__ import annotations

def explain_tradeoff(choice: str) -> str:
    normalized = choice.strip().lower()
    recommendations = {
        "simple": "Prefer the simpler option until requirements justify more complexity.",
        "performance": "Measure first, then optimize the code path that actually dominates runtime.",
        "api": "Choose the option that makes the public contract hardest to misuse.",
    }
    return recommendations.get(normalized, "Clarify constraints before choosing an implementation.")


print(explain_tradeoff("api"))
```

Step by step: normalize input, map known scenarios to recommendations, and provide a safe default for ambiguous cases.

## Summary
- Enum is both a syntax topic and a design topic.
- Interview-ready answers combine definition, example, trade-off, edge case, and production relevance.
- Practice writing small executable snippets and explaining complexity clearly.

## Related
- [../coding-exercises/README.md](../coding-exercises/README.md)
- [../cheat-sheets/python-syntax.md](../cheat-sheets/python-syntax.md)
